import time

numTimes = int(input("please enter the number: "))
def countdown(count):
    while (count >= 0):
        print (count)
        count -= 1
       

countdown(numTimes)
print ("!DONE!")