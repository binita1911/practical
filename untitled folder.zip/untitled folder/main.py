
n = int(input("Enter a number: "))
if n % 2 == 0 and n % 3 == 0:
    print 'Both'
elif n % 2 == 0 and n % 3 != 0:
    print 'one'
elif n % 2 != 0 and n % 3 == 0:
    print 'one'
else:
    print 'neither'